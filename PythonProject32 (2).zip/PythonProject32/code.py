import random



class Code:
    """
    The Code class generates a secret code.
    """
    def __init__(self, length : int, value: str =""):
        """
        initializes the Code object with value which is an empty string and calls the generate_code method.
        """
        self.value = value
        self.length = length
        self.generate_code()
    def generate_code(self) -> None:
        """
        generate_code() generates a string with 4 random numbers from 0-9 as the secret code.
        """
        self.value = "" # sets the value to an empty string


        while len(self.value) < self.length:
            digit = str(random.randint(0, 9))
            if digit not in self.value:
                self.value += digit



    def get_code(self) -> str:
        """
        get_code() returns the secret code.
        """
        return self.value


