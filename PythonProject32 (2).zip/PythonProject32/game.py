from code import Code
from player import Player
from evaluator import Evaluator

class Game:
    """
    The Game class controls the flow of the game
    """
    def __init__(self, secret_code: Code, player: Player, evaluator: Evaluator, max_attempts: int) -> None:
        """
        initializes the Game object with:
        1. secret_code : the code the player has to guess
        2. player
        3. evaluator
        4. max_points : max number of attempts the player can use
        """
        self.code = secret_code
        self.player = player
        self.evaluator = evaluator
        self.max_attempts = max_attempts

    def set_up(self):
        """
               Sets up the game by choosing difficulty and generating a code.
               """
        while True:
            length = input("Choose code length (4, 6, 8): ")
            if length == "4" or length == "6" or length == "8":
                self.code = Code(int(length)) # create a Code object using length that user enters
                break
            print("Please enter 4, 6, or 8.")
        return length

    def play(self) -> None:
        """
        play() generates a secret code and then prompts the user for guesses until they either win or lose.
        """

        self.set_up()
        secret = self.code.get_code()  # Gets secret code
        while True:

            guess = self.player.make_guess()
            if not guess.isdigit() or len(guess) != len(secret):
                print(f"Guess must be {len(secret)} digits")
            else:
                self.player.store_guess(guess)

                exact, partial = self.evaluator.evaluate(secret, guess) # Evaluates how many exact matches there are and how many partial matches
                print(f"exact: {exact} partial: {partial}")
                if self.process_turn(exact): # If player wins or loses, exit while loop
                    break



    def process_turn(self, exact_matches) -> bool:
        """
        process_turn() evaluates each guess and checks if it's a win or a loss.
        """
        if self.check_win(exact_matches):
            return True
        if self.check_loss():
            return True
        return False




    def check_win(self, exact_matches) -> bool:
        """
        check_win() checks if player guesses all numbers correctly.
        """
        if exact_matches == len(self.code.get_code()): # if there are the same number of exact_matches as the length of the secret code, the player wins.
            print("You won!!!!")
            print(f"The secret code was {self.code.get_code()}")
            return True
        return False

    def check_loss(self) -> bool:
        """
        check_loss() checks if player runs out of attempts.
        """
        if self.player.get_attempts_used() >= self.max_attempts: # if used the max number of attempts, they lose.
            print("You have no attempts left. Game over:(")
            print(f"The secret code was {self.code.get_code()}")
            return True
        return False

game = Game(Code(0), Player([], 0), Evaluator(), max_attempts=8)

game.play()