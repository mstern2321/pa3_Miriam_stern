class Player:
    """
    The Player class keeps track of guesses and attempts.
    """
    def __init__(self, guesses : list, attempts_used: int = 0):
        """
        initializes the Player object with a list for guesses and attempts_used which is set at 0.
        """
        self.guesses = guesses
        self.attempts_used = attempts_used

    def make_guess(self) -> str:
        """
        make_guess() prompts user to guess a code and returns the guess.
        """
        guess = input("Make a guess: ")
        return guess
    def store_guess(self, guess) -> None:
        """
        store_guess() adds the guess to the list and increments 1 to attempts_used.
        """
        self.guesses.append(guess)
        self.attempts_used += 1
    def get_attempts_used(self) -> int:
        """
        get_attempts_used() returns the number of attempts the player has used.
        """
        return self.attempts_used


