class Evaluator:
    """
    The Evaluator class compares the player's guess to the secret code.
    """
    def evaluate(self, secret, guess):
        """
        evaluate() returns the number of exact matches and partial matches as a tuple
        """
        exact = self.count_exact(secret, guess)
        partial = self.count_partial(secret, guess)
        return exact, partial

    def count_exact(self, secret, guess):
        """
        count_exact() counts how many exact matches there are.
        """
        count = 0
        for i in range(len(secret)):
            if secret[i] == guess[i]: # If the same  number is in the same position in both codes, 1 is incremented to the count.
                count += 1
        return count

    def count_partial(self, secret, guess):
        """
        count_partial() checks how many numbers are in both codes but not in the same position.
        """
        count = 0
        secret = list(secret)
        guess = list(guess)

        for i in range(len(secret)):
            if secret[i] == guess[i]: # If they are exact matches switch both numbers to an empty space
                secret[i] = " "
                guess[i] = " "
        for num in secret:
            if num != " " and num in guess: # if the number is not an empty space and the number is in guess, increment 1 to count and remove the number from guess so it's not counted more than once.
                count += 1
                guess.remove(num)

        return count
